.. automodule:: nipap.xmlrpc
   :members:
