.. automodule:: nipap.authlib
   :members:
