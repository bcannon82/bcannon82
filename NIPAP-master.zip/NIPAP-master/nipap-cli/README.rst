NIPAP shell command
===================
NIPAP is a system built for managing large amounts of IP addresses built as an
XML-RPC service. This package contains a shell command which accesses this
service.
