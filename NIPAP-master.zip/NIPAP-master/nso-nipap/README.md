NSO package of NIPAP client
===========================
This is a Cisco NSO (formerly Tail-F NCS) package for communicating with a
NIPAP backend.

Installation is simple, merely symlink the nso-nipap package into
ncs-run/packages.
