=========================
NIPAP performance testing
=========================

As NIPAP gained feature completeness one tends to focus on other areas and one of them is naturally performance. 


