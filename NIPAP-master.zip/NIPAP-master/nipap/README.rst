NIPAP - Neat IP Address Planner
===============================
NIPAP is a system built for managing large amounts of IP addresses built as an
XML-RPC service.
